import socket
import sys
import time
import threading
import json
from Interpretor import Interpretor
from CustomGame import CustomGame
from RoomManager import RoomManager
 
HOST = '127.0.0.1'
PORT = 8880

### Codes

# 1 ->

###
gameModeFileName = "Macaua_v1.txt"
interpretor = Interpretor("GameModes/" + gameModeFileName)
# interpretor = Interpretor("GameModes/Simple_Game_Mode.txt")
 
s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
print ('Socket created')

try:
    s.bind((HOST, PORT))
except socket.error as msg:
    print ('Bind failed. Error Code : ' + str(msg[0]) + ' Message ' + msg[1])
    sys.exit()

print ('Socket bind complete')
 
#Start listening on socket
s.listen(10)
print ('Socket now listening')

def startGame(indexOfRoom):
	global rooms
	global interpretor

	while(len(rooms[indexOfRoom]) < interpretor.getMaxNumberOfPlayers()):
		print("Waiting for players")
		firstPlayer = rooms[indexOfRoom][0]
		message = "Do you want to wait for " + str(interpretor.getMaxNumberOfPlayers()) + " players ?"
		message = message + " Or start with " + str(len(rooms[indexOfRoom])) + " players. (wait / start)"
		code = "1" # waiting for players code
		numberOfPlayers = len(rooms[indexOfRoom])
		firstPlayer.send(json.dumps({"message" : message, "code" : code, "numberOfPlayers" : numberOfPlayers} ))
		response = firstPlayer.recv(1024)


		response = response.replace("\r", "").replace("\n", "")

		if response == "start":
			break

		time.sleep(5)

	playersSockets = rooms.pop(indexOfRoom)

	customGame = CustomGame(interpretor, playersSockets)

	while customGame.gameEnded != True:

		currentPlayer = None
		currentPlayerState = None
		currentPlayerIndex = None

		if len(customGame.players) == 1:
			customGame.gameEnded = True
			customGame.players[0].getSocket().send(json.dumps({"gameEnded" : True, "code" : "3", "win" : False}))
			break

		for player in customGame.players:
			playerState = customGame.getCurrentStateForPlayer(player)
			
			if player.isYourTurn() == True:
				print ("am setat currentPlayer")
				currentPlayer = player
				player.setYourTurn(False)
				currentPlayerState = playerState
				currentPlayerIndex = customGame.players.index(player)

			player.getSocket().send(json.dumps(playerState))

		response = currentPlayer.getSocket().recv(1024)

		handlePlayerTurn(response, currentPlayerIndex, currentPlayerState, customGame, customGame.players)

		indexOfPlayer = customGame.players.index(currentPlayer)
		indexOfNextPlayer = indexOfPlayer + 1

		if indexOfNextPlayer == len(customGame.players):
			indexOfNextPlayer = 0

		while customGame.players[indexOfNextPlayer].getWaitTimes() > 0:
			customGame.players[indexOfNextPlayer].removeOneTimeToWait()

			indexOfNextPlayer = indexOfNextPlayer + 1

			if indexOfNextPlayer == len(customGame.players):
				indexOfNextPlayer = 0
		
		customGame.players[indexOfNextPlayer].setYourTurn(True)

		if len(currentPlayer.getCards()) == 0:
			customGame.removePlayer(currentPlayer)
			currentPlayer.playerGameEnded = True
			currentPlayer.getSocket().send(json.dumps({"gameEnded" : True, "code" : "3", "win" : True}))


		for player in customGame.players:
			playerState = customGame.getCurrentStateForPlayer(player)
			
			player.getSocket().send(json.dumps(playerState))

	# game ended
	for player in customGame.players:
		customGame.removePlayer(player)
		currentPlayer.getSocket().send(json.dumps({"gameEnded" : True, "code" : "3", "win" : False}))
		currentPlayerState.getSocket().close()

def gameHandler(connection):
	global rooms

	if len(rooms) > 0:
		if len(rooms[-1]) < interpretor.getMaxNumberOfPlayers():
			rooms[-1].append(connection)
		else:
			newRoom = list()
			newRoom.append(connection)
			rooms.append(newRoom)
			indexOfRoom = rooms.index(newRoom)

			threading.Thread(target=startGame, args=(indexOfRoom,)).start()
	else:
		newRoom = list()
		newRoom.append(connection)
		rooms.append(newRoom)
		indexOfRoom = rooms.index(newRoom)
		
		threading.Thread(target=startGame, args=(indexOfRoom,)).start()

def handlePlayerTurn(response, playerIndex, playerState, customGame, players):
	response = response.replace("\r", "").replace("\n", "")
	cardsCurrentTurn = response.split(",")
	print ("sunt in handle player turn")
	print (cardsCurrentTurn)
	if cardsCurrentTurn[0] == "getNewCard":
		players[playerIndex].addCards([customGame.cardsArray.pop(0)])
		print ("am adaugat carte")
	
	elif len(cardsCurrentTurn) > 1:
			validGroupOfCards = playerState["validGroupsOfCards"]
			print ("cardsCurrentTurn e mai mare ca 1")
			for card in cardsCurrentTurn:
				print (card)
				#card = str(card)
			customGame.currentCard = cardsCurrentTurn[-1]
			if True:#cardsCurrentTurn in validGroupOfCards:
				for card in cardsCurrentTurn:
					cardActions = customGame.getCardActions(card)

					if "ADD_NEXT_PLAYER_CARDS" in cardActions:
						numberOfCards = cardActions["ADD_NEXT_PLAYER_CARDS"]

						indexOfNextPlayer = playerIndex + 1

						if indexOfNextPlayer == len(players):
							indexOfNextPlayer = 0

						nextPlayer = players[indexOfNextPlayer]
						print("numberOfCards------")
						print(numberOfCards)
						for index in range(0, numberOfCards):
							nextPlayer.addCardToTake(customGame.cardsArray.pop(0))
						# in case that current player needs to get cards, then we put the cards to the next player
						for card in players[playerIndex].getCardsToTake():
							nextPlayer.addCardToTake(card)
						players[playerIndex].removeAllCardsToTake()


					if "REMOVE_ADD_NEXT_PLAYER_CARDS" in cardActions:
						cardsToTake = players[playerIndex].getCardsToTake()

						if len(cardsToTake) > 0:
							customGame.cardsArray.extend(cardsToTake)
							players[playerIndex].removeAllCardsToTake()

					if "REMOVE_NEXT_PLAYER_TURNS" in cardActions:
						numberOfTurns = cardActions["REMOVE_NEXT_PLAYER_TURNS"]

						indexOfNextPlayer = playerIndex + 1

						if indexOfNextPlayer == len(players):
							indexOfNextPlayer = 0

						nextPlayer = players[indexOfNextPlayer]

						for index in range(0, numberOfTurns):
							nextPlayer.addOneTimeToWait()
					print("Card de sters ")
					print(card)
					customGame.cardsArray.append(card)
					players[playerIndex].removeCardFromCards(card)


	else:
		print ("cardsCurrentTurn nu e mai mare ca 1")
		print ("current turn[0] -> " + str(cardsCurrentTurn[0]))
		print ("playerState['validCards'] -> " + str(playerState["validCards"]))
		cardsCurrentTurn[0] = str(cardsCurrentTurn[0])
		customGame.currentCard = cardsCurrentTurn[0]
		if True:#cardsCurrentTurn[0] in playerState["validCards"]:
			print (" este in valid cards")
			card = cardsCurrentTurn[0]
			cardActions = customGame.getCardActions(card)

			if "ADD_NEXT_PLAYER_CARDS" in cardActions:
				numberOfCards = cardActions["ADD_NEXT_PLAYER_CARDS"]

				indexOfNextPlayer = playerIndex + 1

				if indexOfNextPlayer == len(players):
					indexOfNextPlayer = 0

				nextPlayer = players[indexOfNextPlayer]
				
				for index in range(0, numberOfCards):
					nextPlayer.addCardToTake(customGame.cardsArray.pop(0))

				# in case that current player needs to get cards, then we put the cards to the next player
				for card in players[playerIndex].getCardsToTake():
					nextPlayer.addCardToTake(card)
					players[playerIndex].removeAllCardsToTake()
	

			if "REMOVE_ADD_NEXT_PLAYER_CARDS" in cardActions:
				cardsToTake = player.getCardsToTake()

				if len(cardsToTake) > 0:
					customGame.cardsArray.extend(cardsToTake)
					players[playerIndex].removeAllCardsToTake()

			if "REMOVE_NEXT_PLAYER_TURNS" in cardActions:
				numberOfTurns = cardActions["REMOVE_NEXT_PLAYER_TURNS"]


				indexOfNextPlayer = playerIndex + 1

				if indexOfNextPlayer == len(players):
					indexOfNextPlayer = 0

				nextPlayer = players[indexOfNextPlayer]

				for index in range(0, numberOfTurns):
					nextPlayer.addOneTimeToWait()

			customGame.cardsArray.append(card)
			players[playerIndex].removeCardFromCards(card)

	cardsToTake = players[playerIndex].getCardsToTake()
	if len(cardsToTake) > 0:
		players[playerIndex].cards.extend(cardsToTake)
		players[playerIndex].removeAllCardsToTake()


# Main

rooms = list()

while True:
	print ("Server in asteptare ...")
	connection, address = s.accept()
	threading.Thread(target=gameHandler, args=(connection,)).start()
	print ("While True end")

# setupGameMode("GameModes/joc.txt")

