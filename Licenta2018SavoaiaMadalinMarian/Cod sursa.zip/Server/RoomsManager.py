import socket, threading

class RoomsManager:
	rooms = None
	max_players_in_room = None

	def __init__(self, maxPlayers):
		self.rooms = list()
		self.max_players_in_room = maxPlayers

	def addPlayerInRoom(player):
		if len(self.rooms) > 0:
			lastRoom = self.rooms[-1]

			if len(lastRoom) < self.max_players_in_room:
				lastRoom.append(player)
				self.rooms[-1] = lastRoom
			
			else:
				newRoom = list()
				newRoom.append(player)
				self.rooms.append(newRoom)
		else:
			newRoom = list()
			newRoom.append(player)
			self.rooms.append(newRoom)