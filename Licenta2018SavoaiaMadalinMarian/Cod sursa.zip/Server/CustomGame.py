from random import shuffle
import json

class Player:
	socket = None
	cards = None
	cardsToTake = None
	yourTurn = None
	canGetNewCard = None
	waitTimes = None
	playerGameEnded = None

	def __init__ (self):
		self.playerGameEnded = False
		self.youtTurn = False

	def setSocket(self, socket):
		self.socket = socket

	def addCards(self, cards):
		if self.cards is None:
			self.cards = list()
		for card in cards:
			self.cards.append(card)

	def addCardToTake(self, card):
		if self.cardsToTake is None:
			self.cardsToTake = list()
		self.cardsToTake.append(card)

	def removeAllCardsToTake(self):
		if self.cardsToTake is None:
			self.cardsToTake = list()
		self.cardsToTake = list()

	def setYourTurn(self, yourTurn):
		self.yourTurn = yourTurn

	def setCanGetNewCard(self, canGetNewCard):
		self.canGetNewCard = canGetNewCard

	def addOneTimeToWait(self):
		if self.waitTimes is None:
			self.waitTimes = 0
		self.waitTimes += 1

	def getSocket(self):
		return self.socket

	def getCards(self):
		return self.cards

	def getCardsToTake(self):
		if self.cardsToTake is None:
			self.cardsToTake = list()
		return self.cardsToTake

	def isYourTurn(self):
		if self.yourTurn is None:
			self.yourTurn = False
		return self.yourTurn

	def getCanGetNewCard(self):
		if self.canGetNewCard is None:
			self.canGetNewCard = False
		return self.canGetNewCard

	def getWaitTimes(self):
		if self.waitTimes is None:
			self.waitTimes = 0
		return self.waitTimes
	def removeOneTimeToWait(self):
		if self.waitTimes is None:
			self.waitTimes = 0
		if self.waitTimes > 0:
			self.waitTimes = self.waitTimes - 1

	def removeCardFromCards(self, card):
		if card in self.cards:
			self.cards.remove(card)

	def removeCardFromCardsToTake(self, card):
		if card in self.cardsToTake:
			self.cardsToTake.remove(card)

class CustomGame:

	players = None

	notInitialCards = None
	isPlayersOrderRandom = None
	numberOfCardsPerPlayer = None

	cardsArray = None
	cardsActionsDictionary = None
	acceptedCardsGroupsInOneTurn = None
	currentCard = None
	gameEnded = None

	def setupPlayers(self, sockets):
		
		for socket in sockets:
			player = Player()
			player.setSocket(socket)
			self.players.append(player)

		if self.isPlayersOrderRandom == True:
			suffle(self.players)

		shuffle(self.cardsArray)

		for player in self.players:
			# set cards
			numberOfCards = 0
			for card in self.cardsArray:
				if numberOfCards < self.numberOfCardsPerPlayer:
					player.addCards([card])
					self.cardsArray.remove(card)
					numberOfCards += 1
				else:
					break
			# set first player turn
			if self.players.index(player) == 0:
				player.setYourTurn(True)

	def isForInitialCard(self, card):
		if card in self.notInitialCards:
			return False
		return True

	def isValidThisState(self, currentCard, playerCard):

		currentCardNumber = ""
		if len(currentCard) == 2:
			currentCardNumber = currentCard[:1]
		else:
			currentCardNumber = currentCard[:2]

		playerCardNumber = ""
		if len(playerCard) == 2:
			playerCardNumber = playerCard[:1]
		else:
			playerCardNumber = playerCard[:2]

		# Cartile au acelasi numar, deci validam
		if currentCardNumber == playerCardNumber:
			return True

		playerCardSymbol = playerCard[-1:]
		currentCardSymbol = currentCard[-1:]

		if currentCardNumber + "\n" in self.cardsActionsDictionary.keys():

			cardDictionary = self.cardsActionsDictionary[currentCardNumber + "\n"]

			if "NEXT_CARDS_ACCEPTED" in cardDictionary:
				nextCardsAccepted = cardDictionary["NEXT_CARDS_ACCEPTED"]
			else:
				nextCardsAccepted = ["ALL"]

			if "ACCEPT_JUST_SAME_SYMBOL" in cardDictionary:
				acceptJustSameSymbol = cardDictionary["ACCEPT_JUST_SAME_SYMBOL"]
			else:
				acceptJustSameSymbol = "FALSE"

			if nextCardsAccepted == ["ALL"] and acceptJustSameSymbol == "TRUE":
				if playerCardSymbol == currentCardSymbol:
					return True
				else:
					return False
			elif nextCardsAccepted == ["ALL"] and acceptJustSameSymbol == "FALSE":
				return True
			elif acceptJustSameSymbol == "TRUE":
				if playerCardNumber in nextCardsAccepted:
					if playerCardSymbol == initialCardSymbol:
						return True
			elif acceptJustSameSymbol == "FALSE":
				if playerCardNumber in nextCardsAccepted:
					return True

		return False

	def getValidCardsForPlayer(self, player, currentCard):

		validCards = list()

		for playerCard in player.getCards():
					if self.isValidThisState(currentCard, playerCard) == True:
						validCards.append(playerCard)

		return validCards

	def getValidGroupsOfCardsForPlayer(self, player, currentCard):

		validGroupsOfCards = list()

		for group in self.acceptedCardsGroupsInOneTurn:

			newGroup = list()

			for card in player.getCards():
				if card in group:
					newGroup.append(card)

			if len(newGroup) > 1:
				mach = False
				for card in newGroup:
					if self.isValidThisState(currentCard, card) == True:
						validGroupsOfCards.append(newGroup)
						break

		return validGroupsOfCards

	def getCurrentStateForPlayer(self, player):

		if player.isYourTurn() == True:
			if player.getWaitTimes() == 0 and len(self.cardsArray) > 0:
				player.setCanGetNewCard(True)
			else:
				player.setCanGetNewCard(False)
		else:
			player.setCanGetNewCard(False)

		state = {}
		state['currentCard'] = self.currentCard
		state['isYourTurn'] = player.isYourTurn()
		state['cards'] = player.getCards()

		state['canGetNewCard'] = player.getCanGetNewCard()

		state['waitTimes'] = player.getWaitTimes()
		state['validCards'] = self.getValidCardsForPlayer(player, self.currentCard)
		state['validGroupsOfCards'] = self.getValidGroupsOfCardsForPlayer(player, self.currentCard)
		state['cardsToTake'] = player.getCardsToTake()
		state['code'] = "2" # in game code

		return state

	def getCardActions(self, card):

		cardActions = {}

		playerCardNumber = ""
		if len(card) == 2:
			playerCardNumber = card[:1]
		else:
			playerCardNumber = card[:2]

		if playerCardNumber + "\n" in self.cardsActionsDictionary.keys():
			cardActions = self.cardsActionsDictionary[playerCardNumber + "\n"]

		return cardActions

	def removePlayer(self, player):
		self.players.remove(player)

		
	def __init__(self, interpretor, sockets):

		self.players = list()

		self.cardsArray = ["11", "12", "13", "14",
					"21", "22", "23", "24",
					"31", "32", "33", "34",
					"41", "42", "43", "44",
					"51", "52", "53", "54",
					"61", "62", "63", "64",
					"71", "72", "73", "74",
					"81", "82", "83", "84",
					"91", "92", "93", "94",
					"101", "102", "103", "104",
					"111", "112", "113", "114",
					"121", "122", "123", "124",
					"131", "132", "133", "134",
					"141", "142"]

		self.numberOfCardsPerPlayer = interpretor.getNumberOfCardsPerPlayer()

		self.isPlayersOrderRandom = False
		self.currentCard = ""
		self.gameEnded = False

		self.isPlayersOrderRandom = interpretor.isPlayersOrderRandom()
		self.cardsActionsDictionary = interpretor.getCardsActionsDictionary()
		self.notInitialCards = interpretor.getNotInitialCards()
		self.acceptedCardsGroupsInOneTurn = interpretor.getAcceptedCardsGroupsInOneTurn()

		self.setupPlayers(sockets)

		while self.isForInitialCard(self.cardsArray[0]) == False:
			shuffle(self.cardsArray)

		# set initial currentCard
		self.currentCard = self.cardsArray[0]
		self.cardsArray.remove(self.currentCard)
