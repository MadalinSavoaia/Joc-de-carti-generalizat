
class RoomManager:
	room = None
	max_players_in_room = None

	def __init__(self, maxPlayers):
		self.room = list()
		self.max_players_in_room = maxPlayers

	def addPlayer(player):
		if len(self.room) < self.max_players_in_room:
			self.room.append(player)
			return True
		return False