import socket, threading
from Room import Room
from Game import Game

rooms = list()

def connectionHandler(client):
	print "connectionHandler start"
	global rooms
	if len(rooms) == 0:
		print("Nu sunt camere disponibile")
		newRoom = Room(client)
		rooms.append(newRoom)
		roomThreadHandler(newRoom)
	else:
		print("Sunt camere disponibile")
		playerInsertedInRoom = False
		for room in rooms:
			if room.getNumberOfPlayers() < 2:
				room.appendPlayer(client)
				playerInsertedInRoom = True
				break
		if playerInsertedInRoom == False:
			newRoom = Room(client)
			rooms.append(newRoom)
			roomThreadHandler(newRoom)
	print "connectionHandler end"

def roomThreadHandler(room):
	print "connectionThreadHandler start"
	global rooms
	while room.getNumberOfPlayers() < 2:
		print "Waiting for players ..."
	rooms.remove(room)
	# rooms = list()
	thread = threading.Thread(target=startGame, args=(room.getPlayers(),))
	thread.start()
	thread.join()
	# startGame(room.getPlayers())
	print "connectionThreadHandler end"

def startGame(players):
	roomPlayers = players
	game = Game(players)
	game.start()


server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
host = socket.gethostname()
server.bind(('192.168.43.206', 54321))#('192.168.45.52', 54321))
server.listen(5)
while True:
	print "Server in asteptare ..."
	connection, address = server.accept()
	threading.Thread(target=connectionHandler, args=(connection,)).start()
	print "While True end"