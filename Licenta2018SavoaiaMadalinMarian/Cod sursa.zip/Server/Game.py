from random import shuffle
import json

class Game:
	sockets = list()
	cardsArray = ["1i", "2i", "3i", "4i", "5i", "6i", "7i", "8i", "9i", "10i", "11i", "12i", "13i",
					"1r", "2r", "3r", "4r", "5r", "6r", "7r", "8r", "9r", "10r", "11r", "12r", "13r",
					"1f", "2f", "3f", "4f", "5f", "6f", "7f", "8f", "9f", "10f", "11f", "12f", "13f",
					"1t", "2t", "3t", "4t", "5t", "6t", "7t", "8t", "9t", "10t", "11t", "12t", "13t",
					"jr", "jn"]
	playersCards = list()
	initialCard = ""
	gameEnded = False
	def __init__(self, socketList):
		for socket in socketList:
			self.sockets.append(socket)
	def isForInitialCard(self, card):
		notInitialCards = ["1i", "1r", "1f", "1t",
							"2i", "2r", "2f", "2t",
							"3i", "3r", "3f", "3t",
							"4i", "4r", "4f", "4t",
							"7i", "7r", "7f", "7t",
							"jr", "jn"]
		if card in notInitialCards:
			return False
		return True

	def isValidThisState(self, initialCard, myCard):
		return True
		if len(myCard) == 2 and myCard[0] == "1":
			return True
		if len(initialCard) != len(myCard):
			return False
		elif len(initialCard) == 2:
			if initialCard[0] == myCard[0]:
				return True
		return False

	def sendStateForSocket(self, socket, your_turn):
		data = {}
		data['initial_card'] = self.initialCard

		socketIndex = self.sockets.index(socket)
		data['cards'] = self.playersCards[socketIndex]
		index = self.sockets.index(socket)
		data['your_turn'] = your_turn

		if len(self.playersCards[index]) == 0:
			data['game_ended'] = True
			if self.gameEnded == False:
				data['win'] = True
				self.gameEnded = True
			else:
				data['win'] = False
			self.sockets.remove(socket)
		if your_turn == True:
			validCards = list()

			for card in self.playersCards[index]:
				if self.isValidThisState(self.initialCard, card) == True:
					validCards.append(card)
			data['valid_cards'] = validCards

			if len(self.cardsArray) > 0:
				data['canGetNewCard'] = True
			else:
				data['canGetNewCard'] = False

		json_data = json.dumps(data)

		socket.send(json_data)
		if 'game_ended' in data:
			if data['game_ended'] == True:
				socket.close()	
	def start(self):
		shuffle(self.cardsArray)
		shuffle(self.sockets)
		print(str(len(self.sockets)) + " socketi conectati.")
		for socket in self.sockets:
			newPlayerCards = list()
			for card in self.cardsArray:
				newPlayerCards.append(card)
				self.cardsArray.remove(card)
				if len(newPlayerCards) == 5:
					break
			self.playersCards.append(newPlayerCards)

		while self.isForInitialCard(self.cardsArray[0]) == False:
			shuffle(self.cardsArray)
		self.initialCard = self.cardsArray[0]
		self.cardsArray.remove(self.initialCard)
		for socket in self.sockets:
			data = {}
			data['initial_card'] = self.initialCard

			socketIndex = self.sockets.index(socket)
			data['cards'] = self.playersCards[socketIndex]
			index = self.sockets.index(socket)
			if index == 0:
				data['your_turn'] = True
				validCards = list()

				for card in self.playersCards[index]:
					if self.isValidThisState(self.initialCard, card) == True:
						validCards.append(card)
				data['valid_cards'] = validCards
				if len(self.cardsArray) > 0:
					data['canGetNewCard'] = True
				else:
					data['canGetNewCard'] = False
			else:
				data['your_turn'] = False
			json_data = json.dumps(data)

			socket.send(json_data)

		while True:
			index = 0
			for socket in self.sockets:
				msg = socket.recv(512)

				if msg == "newCard":
					index = self.sockets.index(socket)
					newCard = self.cardsArray[0]
					self.cardsArray.remove(newCard)
					self.playersCards[index].append(newCard)
				else:
					self.initialCard = msg
					print "A fost pusa cartea " + msg

					# eliminare carte de joc din playersCards[index]
					index  = self.sockets.index(socket)
					for card in self.playersCards[index]:
						if card == msg:  
							self.cardsArray.append(card)
							self.playersCards[index].remove(card)
					#------------------------------------------------

				for socket2 in self.sockets:
					self.sendStateForSocket(socket2, False)
				index = index + 1

				if index < len(self.sockets):
					self.sendStateForSocket(self.sockets[index], True)
				else:
					self.sendStateForSocket(self.sockets[0], True)


				print("mai am " + str(len(self.sockets)) + " socketi connectati")
				if len(self.sockets) == 0:
					print("Facem break")
					break


# game = Game(["a", "b"])
# game.start()
# print game.cardsArray
# print game.sockets
# print game.firstPlayerCards
# print game.secondPlayerCards