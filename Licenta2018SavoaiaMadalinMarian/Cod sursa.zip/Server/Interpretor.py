class Interpretor:
	
	GAME_MODE_NAME = ""
	NUMBER_OF_CARDS = 0
	NUMBER_OF_CARDS_PER_PLAYER = 0
	MAX_NUMBER_OF_PLAYERS = 0
	MIN_NUMBER_OF_PLAYERS = 0
	NUMBER_OF_CARDS_FOR_WIN = 0
	MAX_NUMBER_OF_CARDS_IN_ONE_TURN = 0
	ACCEPTED_CARDS_GROUPS_IN_ONE_TURN = list()
	CARDS_ACTIONS_DICTIONARY = {}
	NOT_INITIAL_CARDS = list()
	PLAYERS_ORDER_RANDOM = "FALSE"

	def __init__(self, configFile):

		config = open(configFile)

		line = config.readline()

		while line:

			if line == "GAME_MODE_NAME\n":
				line = config.readline().replace("\n", "")
				self.GAME_MODE_NAME = line
			
			elif line == "NUMBER_OF_CARDS\n":
				line = config.readline()
				self.NUMBER_OF_CARDS = int(line)

			elif line == "PLAYERS_ORDER_RANDOM\n":
				line = config.readline()
				self.PLAYERS_ORDER_RANDOM = line.replace("\n", "")

			elif line == "NUMBER_OF_CARDS_PER_PLAYER\n":
				line = config.readline()
				self.NUMBER_OF_CARDS_PER_PLAYER = int(line)

			elif line == "MAX_NUMBER_OF_PLAYERS\n":
				line = config.readline()
				self.MAX_NUMBER_OF_PLAYERS = int(line)

			elif line == "MIN_NUMBER_OF_PLAYERS\n":
				line = config.readline()
				self.MIN_NUMBER_OF_PLAYERS = int(line)

			elif line == "NUMBER_OF_CARDS_FOR_WIN\n":
				line = config.readline()
				self.NUMBER_OF_CARDS_FOR_WIN = int(line)

			elif line == "MAX_NUMBER_OF_CARDS_IN_ONE_TURN\n":
				line = config.readline()
				self.MAX_NUMBER_OF_CARDS_IN_ONE_TURN = int(line)

			elif line == "ACCEPTED_CARDS_GROUPS_IN_ONE_TURN\n":
				begin = config.readline()

				if begin == "BEGIN\n":

					line = config.readline()

					while line != "END\n":
						line = line.replace("\n", "")
						self.ACCEPTED_CARDS_GROUPS_IN_ONE_TURN.append(line.split(","))
						line = config.readline()

			elif line == "CARDS_ACTIONS\n":
				card_number = config.readline()

				while card_number:

					card_actions_dictionary = {}

					begin = config.readline()

					if begin == "BEGIN\n":

						line = config.readline()

						while line != "END\n":

							if line == "ADD_NEXT_PLAYER_CARDS\n":
								card_actions_dictionary["ADD_NEXT_PLAYER_CARDS"] = int(config.readline())

							elif line == "REMOVE_NEXT_PLAYER_TURNS\n":
								card_actions_dictionary["REMOVE_NEXT_PLAYER_TURNS"] = int(config.readline())

							elif line == "NEXT_CARDS_ACCEPTED\n":
								NEXT_CARDS_ACCEPTED_STRING = config.readline()
								NEXT_CARDS_ACCEPTED_STRING = NEXT_CARDS_ACCEPTED_STRING.replace("\n", "")
								NEXT_CARDS_ACCEPTED_LIST = NEXT_CARDS_ACCEPTED_STRING.split(",")
								card_actions_dictionary["NEXT_CARDS_ACCEPTED"] = NEXT_CARDS_ACCEPTED_LIST

							elif line == "ACCEPT_JUST_SAME_SYMBOL\n":
								line = config.readline().replace("\n", "")
								ACCEPT_JUST_SAME_SYMBOL = line
								card_actions_dictionary["ACCEPT_JUST_SAME_SYMBOL"] = ACCEPT_JUST_SAME_SYMBOL

							line = config.readline()

					self.CARDS_ACTIONS_DICTIONARY[card_number] = card_actions_dictionary
					card_number = config.readline()

			elif line == "NOT_INITIAL_CARDS\n":
				begin = config.readline()

				if begin == "BEGIN\n":

					line = config.readline()

					while line != "END\n":
						cardsArray = line.replace("\n", "").split(", ")

						for card in cardsArray:
							self.NOT_INITIAL_CARDS.append(card)

						line = config.readline()

			line = config.readline()
		config.close()

	def getGetGameModeName(self):
		print "GAME_MODE_NAME " + str(self.GAME_MODE_NAME)

	def getNumberOfCards(self):
		print "NUMBER_OF_CARDS " + str(self.NUMBER_OF_CARDS)

	def isPlayersOrderRandom(self):
		if self.PLAYERS_ORDER_RANDOM == "TRUE":
			return True
		else:
			return False

	def getNumberOfCardsPerPlayer(self):
		# print "NUMBER_OF_CARDS_PER_PLAYER " + str(self.NUMBER_OF_CARDS_PER_PLAYER)
		return self.NUMBER_OF_CARDS_PER_PLAYER

	def getMaxNumberOfPlayers(self):
		# print "MAX_NUMBER_OF_PLAYERS " + str(self.MAX_NUMBER_OF_PLAYERS)
		return self.MAX_NUMBER_OF_PLAYERS
	def getMinNumberOfPlayers(self):
		print "MIN_NUMBER_OF_PLAYERS " + str(self.MIN_NUMBER_OF_PLAYERS)

	def getNumberOfCardsForWin(self):
		print "NUMBER_OF_CARDS_FOR_WIN " + str(self.NUMBER_OF_CARDS_FOR_WIN)

	def getMaxNumberOfCardsInOneTurn(self):
		print "MAX_NUMBER_OF_CARDS_IN_ONE_TURN " + str(self.MAX_NUMBER_OF_CARDS_IN_ONE_TURN)

	def getAcceptedCardsGroupsInOneTurn(self):
		# print "ACCEPTED_CARDS_GROUPS_IN_ONE_TURN "
		# for group in self.ACCEPTED_CARDS_GROUPS_IN_ONE_TURN:
		# 	print group
		return self.ACCEPTED_CARDS_GROUPS_IN_ONE_TURN

	def getCardsActionsDictionary(self):
		# print "CARDS_ACTIONS_DICTIONARY "
		# for key, value in self.CARDS_ACTIONS_DICTIONARY.iteritems():
		#     print key, value
		return self.CARDS_ACTIONS_DICTIONARY

	def getNotInitialCards(self):
		return self.NOT_INITIAL_CARDS