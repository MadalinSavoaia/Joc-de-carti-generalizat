class Room:
	sockets = list()
	
	def __init__(self, socket):
		self.sockets.append(socket)

	def appendPlayer(self, socket):
		self.sockets.append(socket)

	def getNumberOfPlayers(self):
		return len(self.sockets)

	def getPlayers(self):
		return self.sockets