//
//  AuthenticationViewController.swift
//  Client
//
//  Created by Madalin Savoaia on 4/2/17.
//  Copyright © 2017 Madalin Savoaia. All rights reserved.
//

import UIKit

class AuthenticationViewController: UIViewController {
    
    var delegate: AuthenticationViewControllerProtocol?

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    @IBAction func continueWithFacebookAction(_ sender: Any) {
        // daca autentificarea e cu success
        if true {
            updateTokenTo(value: "token123")
            delegate?.loginSucceeded!()
        }
    }
    
    //MARK: Utils
    
    func updateTokenTo(value: String) {
        UserDefaults.standard.setValue(value, forKey: "token")
        UserDefaults.standard.synchronize()
    }
}
