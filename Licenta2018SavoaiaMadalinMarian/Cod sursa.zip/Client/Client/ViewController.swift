//
//  ViewController.swift
//  Client
//
//  Created by Madalin Savoaia on 15/01/2017.
//  Copyright © 2017 Madalin Savoaia. All rights reserved.
//

import UIKit
import SwiftSocket

class ViewController: UIViewController, UITextFieldDelegate {

    @IBOutlet weak var textView: UITextView!
    @IBOutlet var textField: UITextField!
    
    let host = "127.0.0.1"
    let port = 8886
    
    var client: TCPClient?
    var connected = false
    var dictionary = NSDictionary()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        client = TCPClient(address: host, port: Int32(port))
        textField.delegate = self
    }
    
    @IBAction func connectButtonAction(_ sender: Any) {
        if connected == false {
            guard let client = client else { return }
            
            switch client.connect(timeout: 10) {
            case .success:
                let button: UIButton = sender as! UIButton
                button.isHidden = true
                appendToTextField(string: "Connected to host \(client.address)")
                appendToTextField(string: "Waiting for players ...")

                DispatchQueue.global(qos: .default).async {
                    while(true) {
                        if let response = self.readResponse(from: self.client!) {
                            DispatchQueue.main.async(execute: {
                                self.appendToTextField(string: "Server: " + response)
                                self.dictionary = self.getDictionaryFromResponse(response: response)
                            })
                            
                        }
                    }
                }
                
                
            case .failure(let error):
                appendToTextField(string: "Recv Error: "  + String(describing: error))
            }
            
        }
    }
    @IBAction func sendButtonAction(_ sender: Any) {
        guard let client = client else { return }
        if let yourTurn: Bool = dictionary["your_turn"] as! Bool? {
            if yourTurn == false {
                return
            }
        }
        if textField.text != "" {
            switch client.send(string: textField.text!) {
            case .success:
                appendToTextField(string: "Client: " + textField.text!)
                self.dictionary = NSDictionary()
            case .failure(let error):
                appendToTextField(string: "Send Error: " + String(describing: error))
            }
            
            textField.text = ""
        }
    }
    
    private func sendRequest(string: String, using client: TCPClient) -> String? {
        appendToTextField(string: "Sending data ... ")
        
        switch client.send(string: string) {
        case .success:
            return readResponse(from: client)
        case .failure(let error):
            appendToTextField(string: String(describing: error))
            return nil
        }
    }
    
    private func readResponse(from client: TCPClient) -> String? {
        guard let response = client.read(1024*10) else { return nil }
        
        return String(bytes: response, encoding: .utf8)
    }
    
    private func appendToTextField(string: String) {
        print(string)
        textView.text = textView.text.appending("\n\(string)")
    }
    
    private func getDictionaryFromResponse(response: String) -> NSDictionary {
        let data: Data = response.data(using: String.Encoding.utf8)!
        
        do {
            let dictionary = try JSONSerialization.jsonObject(with: data, options: JSONSerialization.ReadingOptions.mutableLeaves)as! NSDictionary
            return dictionary
        } catch {
            print("Eroare la decodarea JSON")
        }
        
        return ["error" : "Eroare la decodarea JSON"]
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
    
}
