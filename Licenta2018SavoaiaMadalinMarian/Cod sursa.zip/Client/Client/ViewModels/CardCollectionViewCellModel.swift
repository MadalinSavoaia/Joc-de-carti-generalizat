//
//  CardCollectionViewCellModel.swift
//  Client
//
//  Created by Madalin Savoaia on 23/04/2018.
//  Copyright © 2018 Madalin Savoaia. All rights reserved.
//

class CardCollectionViewCellModel {
    
    var card: String
    var selected: Bool
    
    init(card: String, selected: Bool) {
        self.card = card
        self.selected = selected
    }
}
