//
//  GameViewController.swift
//  Client
//
//  Created by Madalin Savoaia on 24/01/2017.
//  Copyright © 2017 Madalin Savoaia. All rights reserved.
//

import UIKit
import SwiftSocket

typealias Cards = Array<String>
typealias GroupsOfCards = Array<Cards>

class GameViewController: UIViewController {

    @IBOutlet var collectionView: UICollectionView!
    @IBOutlet var initialCardImageView: UIImageView!
    @IBOutlet var layer: UIView!
    @IBOutlet var activityIndicator: UIActivityIndicatorView!
    @IBOutlet weak var getNewCard: UIImageView!
    @IBOutlet weak var yourTurnLabel: UILabel!
    @IBOutlet weak var cardsToTakeLabel: UILabel!
    
    let host = "127.0.0.1"
    let port = 8880
    let cellIdentifier = "cardCollectionViewCell"
    
    var client: TCPClient?
    var connected = false
    var dictionary = NSDictionary()
    
    fileprivate var cardsForCurrentTurn = Cards()
    fileprivate var validCardsForCurrentTurn = Cards()
    fileprivate var validGroupsOfCardsForCurrentTurn = GroupsOfCards()
    fileprivate var selectedCards = Cards()
    fileprivate var isYourTurn = false
    
    
    var delegate: GameViewControllerProtocol?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.collectionView.register(UINib(nibName:String(describing: CardCollectionViewCell.self), bundle: nil), forCellWithReuseIdentifier: cellIdentifier)
        
        self.setup()
        
        self.connectToServer()
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewDidAppear(true)
        
        
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func setup() {
        self.activityIndicator.isHidden = true
        
        getNewCard.isUserInteractionEnabled = true
        
        let tapGestureRecognizer = UITapGestureRecognizer(target: self, action: #selector(getNewCardAction))
        getNewCard.addGestureRecognizer(tapGestureRecognizer)
    }
    
    func connectToServer() {
        self.client = TCPClient(address: host, port: Int32(port))
        
        if self.connected == false {
            guard let client = self.client else { return }
            
            switch client.connect(timeout: 10) {
            case .success:
                DispatchQueue.global(qos: .default).async {
                    while(true) {
                        if let response = self.readResponse(from: self.client!) {
                            DispatchQueue.main.async(execute: {
                                self.layer.isHidden = true
                                self.handleServerResponse(response: response)
                            })
                        }
                    }
                }
                
            case .failure:
                DispatchQueue.main.async(execute: {
                    self.showMessage(title: "Attention", message: "Game server connection failed !", dismiss: true)
                })
            }
            
        }
    }
    
    func handleServerResponse(response: String) {
        self.dictionary = self.getDictionaryFromResponse(response: response)
        print(dictionary.debugDescription)
        
        guard let code = dictionary.object(forKey: "code") as? String else { return }
        
        switch code {
        case "1":
            // Wait for players code
            handleWaitForPlayers()
        case "2":
            // In game code
            updateParamsForCurrentTurn()
            handleInGame()
        case "3":
            // Game ended
            handleGameEnded()
        default:
            break
        }
    }
    
    private func readResponse(from client: TCPClient) -> String? {
        guard let response = client.read(1024*10) else { return nil }
        
        return String(bytes: response, encoding: .utf8)
    }
    
    fileprivate func sendMessageToServer(string: String) {
        guard let client = client else { return }
        switch client.send(string: string) {
        case .success:
            self.dictionary = NSDictionary()
        case .failure(let error):
            print("Sending failed: ",error)
        }
        
    }

    private func getDictionaryFromResponse(response: String) -> NSDictionary {
        let data: Data = response.data(using: String.Encoding.utf8)!
        
        do {
            let dictionary = try JSONSerialization.jsonObject(with: data, options: JSONSerialization.ReadingOptions.mutableLeaves)as! NSDictionary
            return dictionary
        } catch {
            print("Eroare la decodarea JSON")
        }
        
        return ["error" : "Eroare la decodarea JSON"]
    }
    
    private func handleWaitForPlayers() {
        let alert = UIAlertController(title: "Alerta", message: "Apasa start pentru a incepe jocul", preferredStyle: .alert)
        let startAction = UIAlertAction(title: "Start", style: .default) { [weak self] (alert) in
            self?.sendMessageToServer(string: "start")
        }
        alert.addAction(startAction)
        present(alert, animated: true, completion: nil)
    }
    
    private func handleInGame() {
        let initialCard = self.dictionary["currentCard"] as! String
        self.initialCardImageView.image = UIImage(named: initialCard)
        let canGetNewCard = self.dictionary["canGetNewCard"] as! Bool?
        if let canGetNewCard2 = canGetNewCard {
            if canGetNewCard2 == true {
                getNewCard.isHidden = false
            } else {
                getNewCard.isHidden = true
            }
        }
        
        if self.isYourTurn == true {
            yourTurnLabel.backgroundColor = Constants.activeLabelColor
        } else {
            yourTurnLabel.backgroundColor = Constants.inactiveLabelColor
        }
        
        if let cardsToTake = self.dictionary.object(forKey: "cardsToTake") as? Array<String> {
            if cardsToTake.count > 0 {
                cardsToTakeLabel.backgroundColor = Constants.activeLabelColor
            } else {
                cardsToTakeLabel.backgroundColor = Constants.inactiveLabelColor
            }
            cardsToTakeLabel.text = "Cards to take: " + String(cardsToTake.count)
        }
    }
    
    private func handleGameEnded() {
        guard let _ = self.dictionary["gameEnded"] as? Bool else { return }
        guard let win = self.dictionary["win"] as? Bool else { return }
        
        client?.close()
        
        if win == true {
            self.showMessage(title: "Attention", message: "You Won !", dismiss: true)
        } else {
            self.showMessage(title: "Attention", message: "You Failed !", dismiss: true)
        }
    }
    
    func showMessage(title: String, message: String, dismiss: Bool) {
        let alertController = UIAlertController(title: title, message: message, preferredStyle: .alert)
        
        let dismissAction = UIAlertAction(title: "Dismiss", style: .cancel) { (alert) in
            if dismiss == true {
                self.delegate?.gameDidClose()
            }
        }
        alertController.addAction(dismissAction)
        self.present(alertController, animated: true, completion: nil)
    }
    
    //MARK: Selectors
    
    func getNewCardAction() {
        self.sendMessageToServer(string: "getNewCard")
    }
    
    //MARK: IBActions
    
    @IBAction func sendAction(_ sender: Any) {
        
        if self.isYourTurn == false {
            return
        }
        
        if selectedCards.count == 1 {
            guard let card = self.selectedCards.first else { return }
            if isCardValid(card: card) == true {
                self.selectedCards.removeAll()
                self.sendMessageToServer(string: card)
                self.collectionView.reloadData()
            } else {
                showMessage(title: "Atentie", message: Constants.noValidCardMessage, dismiss: false)
            }
        } else if selectedCards.count > 0 {
            var isSelectionSent = false
            for group in validGroupsOfCardsForCurrentTurn {
                var isValidSelection = true
                var messageToServerString = ""
                for card in selectedCards {
                    if group.contains(card) {
                        messageToServerString += card
                    } else {
                        isValidSelection = false
                        break
                    }
                    if let index = selectedCards.index(of: card) {
                        // Daca nu este ultima carte
                        if index < selectedCards.count - 1 {
                            messageToServerString += "," // Adauga separator intre carti
                        }
                    }
                }
                if isValidSelection == true {
                    sendMessageToServer(string: messageToServerString)
                    isSelectionSent = true
                    break
                }
            }
            if isSelectionSent {
                // selectia a fost trimisa la server
                self.selectedCards.removeAll()
                print("Trimitem Grupul de carti")
                self.collectionView.reloadData()
            } else {
                // selectia nu a fost trimisa la server
                print("grupul de carti nu este valid")
                showMessage(title: "Atentie", message: Constants.noValidGroupCardsMessage, dismiss: false)
            }
        } else {
            showMessage(title: "Atentie", message: Constants.noCardSelectedMessage, dismiss: false)
        }
    }
    
    //MARK: Private funcs
    
    fileprivate func isCardValid(card: String) -> Bool {
        for currentCard in self.validCardsForCurrentTurn {
            if currentCard == card {
                return true
            }
        }
        return false
    }
    
    private func updateParamsForCurrentTurn() {
        self.cardsForCurrentTurn.removeAll()
        self.validCardsForCurrentTurn.removeAll()
        self.validGroupsOfCardsForCurrentTurn.removeAll()
        
        if let cardsForCurrentTurnWrapped = self.dictionary["cards"] as? [String] {
            self.cardsForCurrentTurn.append(contentsOf: cardsForCurrentTurnWrapped)
        }
        
        if let validCardsForCurrentTurnWrapped = self.dictionary["validCards"] as? [String] {
            self.validCardsForCurrentTurn.append(contentsOf: validCardsForCurrentTurnWrapped)
        }
        
        if let validGroupsOfCardsForCurrentTurnWrapped = self.dictionary["validGroupsOfCards"] as? [[String]] {
            self.validGroupsOfCardsForCurrentTurn.append(contentsOf: validGroupsOfCardsForCurrentTurnWrapped)
        }
        
        if let isYourTurnWrapped = self.dictionary["isYourTurn"] as? Bool {
            self.isYourTurn = isYourTurnWrapped
        }
        
        self.collectionView.reloadData()
    }
}

extension GameViewController: UICollectionViewDelegate {
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        
        if self.isYourTurn == false {
            return
        }
        let cardName = cardsForCurrentTurn[indexPath.row]
        if selectedCards.contains(cardName), let index = selectedCards.index(of: cardName) {
            selectedCards.remove(at: index)
        } else {
            selectedCards.append(cardName)
        }
        collectionView.reloadItems(at: [indexPath])
    }
}

extension GameViewController: UICollectionViewDataSource {
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 1
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return self.cardsForCurrentTurn.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        guard let cell =  collectionView.dequeueReusableCell(withReuseIdentifier: cellIdentifier, for: indexPath) as? CardCollectionViewCell else { return UICollectionViewCell() }
        let cardName = self.cardsForCurrentTurn[indexPath.row]
        let isSelected = selectedCards.contains(cardName)
        let model = CardCollectionViewCellModel(card: cardName, selected: isSelected)
        cell.setup(with: model)
        return cell
    }
}
