//
//  MenuViewController.swift
//  Client
//
//  Created by Madalin Savoaia on 24/01/2017.
//  Copyright © 2017 Madalin Savoaia. All rights reserved.
//

import UIKit

class MenuViewController: UIViewController, GameViewControllerProtocol {

    var delegate: MenuViewControllerProtocol?
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func showGameViewController() {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let gameViewController = storyboard.instantiateViewController(withIdentifier: "gameViewController") as! GameViewController
        gameViewController.delegate = self
    
        self.navigationController?.pushViewController(gameViewController, animated: true)
    }

    @IBAction func playButtonAction(_ sender: Any) {
        showGameViewController()
    }
    
    @IBAction func logoutButtonAction(_ sender: Any) {
        delegate?.logout!()
    }
    
    
    //Mark: GameViewControllerProtocol Delegate Methods
    
    func gameDidClose() {
        navigationController?.popViewController(animated: true)
    }
    
    func gameDidEnd(won: Bool) {
        if won == true {
            // You won the game
        } else {
            // You lost the game
        }
    }
}
