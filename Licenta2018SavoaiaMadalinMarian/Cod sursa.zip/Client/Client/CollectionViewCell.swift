//
//  CollectionViewCell.swift
//  Client
//
//  Created by Madalin Savoaia on 24/01/2017.
//  Copyright © 2017 Madalin Savoaia. All rights reserved.
//

import UIKit

class CollectionViewCell: UICollectionViewCell {
    
}
