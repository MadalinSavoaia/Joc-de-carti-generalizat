//
//  CardCollectionViewCell.swift
//  Client
//
//  Created by Madalin Savoaia on 23/04/2018.
//  Copyright © 2018 Madalin Savoaia. All rights reserved.
//

import UIKit

class CardCollectionViewCell: UICollectionViewCell {

    @IBOutlet weak var cardImage: UIImageView!
    @IBOutlet weak var checkImage: UIImageView!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
    func setup(with model: CardCollectionViewCellModel) {
        cardImage.image = UIImage(named: model.card)
        if model.selected == true {
            checkImage.isHidden = false
        } else {
            checkImage.isHidden = true
        }
    }
}
