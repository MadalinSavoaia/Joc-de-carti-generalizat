//
//  AuthenticationViewControllerProtocol.swift
//  Client
//
//  Created by Madalin Savoaia on 4/2/17.
//  Copyright © 2017 Madalin Savoaia. All rights reserved.
//

import Foundation

@objc protocol AuthenticationViewControllerProtocol {
    @objc optional func loginSucceeded()
}
