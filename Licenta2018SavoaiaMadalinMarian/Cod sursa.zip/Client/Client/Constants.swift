//
//  Constants.swift
//  
//
//  Created by Madalin Savoaia on 16/04/2018.
//

import UIKit

struct Constants {
    static let activeLabelColor = #colorLiteral(red: 0.3596595391, green: 1, blue: 0.2121104905, alpha: 1)
    static let inactiveLabelColor = #colorLiteral(red: 0.8528880477, green: 0, blue: 0, alpha: 1)
    
    static let noCardSelectedMessage = "Selecteaza cel putin o carte, sau trage o noua carte."
    static let noValidGroupCardsMessage = "Acest grup de carti selectat nu este valid."
    static let noValidCardMessage = "Aceasta carte nu este valida."
}
