//
//  RootViewController.swift
//  Client
//
//  Created by Madalin Savoaia on 4/2/17.
//  Copyright © 2017 Madalin Savoaia. All rights reserved.
//

import UIKit

class RootViewController: UIViewController, AuthenticationViewControllerProtocol, MenuViewControllerProtocol {

    var token: String?
    var authenticationViewController: AuthenticationViewController?
    var menuViewController: MenuViewController?
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(true)
        
        handlePresentingFlow()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func handlePresentingFlow() {
        token = UserDefaults.standard.string(forKey: "token")
        if token == "" || token == nil {
            // Push authentication flow
            presentAuthenticationViewController()
            
        } else {
            // Push menuViewController flow
            presentMenuViewController()
        }
    }
    
    func presentAuthenticationViewController() {
        if let localAuthenticationViewController = authenticationViewController {
            localAuthenticationViewController.delegate = self
            
            present(localAuthenticationViewController, animated: true, completion: nil)
        } else {
            let storyboard = UIStoryboard.init(name: "Main", bundle: nil)
            authenticationViewController = storyboard.instantiateViewController(withIdentifier: "authenticationViewController") as? AuthenticationViewController
            authenticationViewController?.delegate = self
            
            self.present(authenticationViewController!, animated: true, completion: nil)
        }
    }
    
    func presentMenuViewController() {
        if let localMenuViewController = menuViewController {
            localMenuViewController.delegate = self
            
            let navigationController = UINavigationController(rootViewController: localMenuViewController)
            navigationController.setNavigationBarHidden(true, animated: false)
            
            present(navigationController, animated: true, completion: nil)
            
        } else {
            let storyboard = UIStoryboard.init(name: "Main", bundle: nil)
            menuViewController = storyboard.instantiateViewController(withIdentifier: "menuViewController") as? MenuViewController
            menuViewController?.delegate = self
            
            let navigationController = UINavigationController(rootViewController: menuViewController!)
            navigationController.setNavigationBarHidden(true, animated: false)
            
            present(navigationController, animated: true, completion: nil)
        }
    }
    
    //MARK: AuthenticationViewControllerProtocol Delegate Methods
    func loginSucceeded() {
        dismiss(animated: true, completion: nil)
    }
    
    //MARK: MenuViewControllerProtocol Delegate Methods
    func logout() {
        updateTokenTo(value: "")
        dismiss(animated: true, completion: nil)
    }
    
    //MARK: Utils
    func updateTokenTo(value: String) {
        UserDefaults.standard.setValue(value, forKey: "token")
        UserDefaults.standard.synchronize()
    }

}
