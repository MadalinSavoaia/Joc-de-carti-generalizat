//
//  MenuViewControllerProtocol.swift
//  Client
//
//  Created by Madalin Savoaia on 4/2/17.
//  Copyright © 2017 Madalin Savoaia. All rights reserved.
//

import Foundation

@objc protocol MenuViewControllerProtocol {
    @objc optional func logout()
}
