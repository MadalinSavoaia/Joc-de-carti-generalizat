<?php

if (check() == True) {

	$file = fopen("gamemode.txt", "wb");

	$newline = "\r\n";

	$buffer = "";

	$buffer = $buffer . "GAME_MODE_NAME" . $newline . $_POST['GAME_MODE_NAME'] . $newline;
	$buffer = $buffer . "NUMBER_OF_CARDS_PER_PLAYER" . $newline . $_POST['NUMBER_OF_CARDS_PER_PLAYER'] . $newline;
	$buffer = $buffer . "MAX_NUMBER_OF_PLAYERS" . $newline . $_POST['MAX_NUMBER_OF_PLAYERS'] . $newline;
	$buffer = $buffer . "MIN_NUMBER_OF_PLAYERS" . $newline . $_POST['MIN_NUMBER_OF_PLAYERS'] . $newline;
	$buffer = $buffer . "NUMBER_OF_CARDS_FOR_WIN" . $newline . $_POST['NUMBER_OF_CARDS_FOR_WIN'] . $newline;
	$buffer = $buffer . "MAX_NUMBER_OF_CARDS_IN_ONE_TURN" . $newline . $_POST['MAX_NUMBER_OF_CARDS_IN_ONE_TURN'] . $newline;
	$buffer = $buffer . "PLAYERS_ORDER_RANDOM" . $newline . strtoupper($_POST['PLAYERS_ORDER_RANDOM']) . $newline;

	// not initial cards
	if (isset($_POST['NOT_INITIAL_CARDS'])) {

		$buffer = $buffer . "NOT_INITIAL_CARDS" . $newline;

		$buffer = $buffer . "BEGIN" . $newline;

		$not_initial_cards = $_POST['NOT_INITIAL_CARDS'];

		foreach ($not_initial_cards as $card) {
			if(array_search($card, $not_initial_cards) == sizeof($not_initial_cards)-1) {
				$buffer = $buffer . $card . $newline;
			} else {
				$buffer = $buffer . $card . ", ";
			}
		}

		$buffer = $buffer . "END" . $newline;
	}


	// accepted cards groups

	$buffer = $buffer . "ACCEPTED_CARDS_GROUPS_IN_ONE_TURN" . $newline;

	$buffer = $buffer . "BEGIN" . $newline;

	for($index = 1; $index <= 14; $index++) {
		$key = "accepted_group_" . $index;

		if (isset($_POST[$key]) && $_POST[$key] != "") {
			$group = $_POST[$key];
			$buffer = $buffer . $group . $newline;
		}
	}

	$buffer = $buffer . "END" . $newline;

	// cards actions

	$buffer = $buffer . "CARDS_ACTIONS" . $newline;

	for ($index = 1; $index <= 14; $index++) {

		$buffer = $buffer . $index . $newline;

		$buffer = $buffer . "BEGIN" . $newline;

		$KEY_NEXT_CARDS_ACCEPTED = $index . "_NEXT_CARDS_ACCEPTED";
		$KEY_ACCEPT_JUST_SAME_SYMBOL = $index . "_ACCEPT_JUST_SAME_SYMBOL";
		$KEY_ADD_NEXT_PLAYER_CARDS = $index . "_ADD_NEXT_PLAYER_CARDS";
		$KEY_REMOVE_NEXT_PLAYER_TURNS = $index . "_REMOVE_NEXT_PLAYER_TURNS";
		$KEY_REMOVE_ADD_NEXT_PLAYER_CARDS = $index . "_REMOVE_ADD_NEXT_PLAYER_CARDS";

		if(isset($_POST[$KEY_NEXT_CARDS_ACCEPTED]) && $_POST[$KEY_NEXT_CARDS_ACCEPTED]) {
			$NEXT_CARDS_ACCEPTED = $_POST[$KEY_NEXT_CARDS_ACCEPTED];

			$buffer = $buffer . "NEXT_CARDS_ACCEPTED" . $newline;
			$buffer = $buffer . $NEXT_CARDS_ACCEPTED . $newline;
		}

		if(isset($_POST[$KEY_ACCEPT_JUST_SAME_SYMBOL]) && $_POST[$KEY_ACCEPT_JUST_SAME_SYMBOL]) {
			$ACCEPT_JUST_SAME_SYMBOL = $_POST[$KEY_ACCEPT_JUST_SAME_SYMBOL];

			$buffer = $buffer . "ACCEPT_JUST_SAME_SYMBOL" . $newline;
			$buffer = $buffer . $ACCEPT_JUST_SAME_SYMBOL . $newline;
		}

		if(isset($_POST[$KEY_ADD_NEXT_PLAYER_CARDS]) && $_POST[$KEY_ADD_NEXT_PLAYER_CARDS]) {
			$ADD_NEXT_PLAYER_CARDS = $_POST[$KEY_ADD_NEXT_PLAYER_CARDS];

			$buffer = $buffer . "ADD_NEXT_PLAYER_CARDS" . $newline;
			$buffer = $buffer . $ADD_NEXT_PLAYER_CARDS . $newline;
		}

		if(isset($_POST[$KEY_REMOVE_NEXT_PLAYER_TURNS]) && $_POST[$KEY_REMOVE_NEXT_PLAYER_TURNS]) {
			$REMOVE_NEXT_PLAYER_TURNS = $_POST[$KEY_REMOVE_NEXT_PLAYER_TURNS];

			$buffer = $buffer . "REMOVE_NEXT_PLAYER_TURNS" . $newline;
			$buffer = $buffer . $REMOVE_NEXT_PLAYER_TURNS . $newline;
		}

		if(isset($_POST[$KEY_REMOVE_ADD_NEXT_PLAYER_CARDS]) && $_POST[$KEY_REMOVE_ADD_NEXT_PLAYER_CARDS]) {
			$REMOVE_ADD_NEXT_PLAYER_CARDS = $_POST[$KEY_REMOVE_ADD_NEXT_PLAYER_CARDS];

			$buffer = $buffer . "REMOVE_ADD_NEXT_PLAYER_CARDS" . $newline;
			$buffer = $buffer . $REMOVE_ADD_NEXT_PLAYER_CARDS . $newline;
		}

		$buffer = $buffer . "END" . $newline;

	}	

	fwrite($file, $buffer);
	fclose($file);

	echo '<a href="gamemode.txt">Download GameMode</a>';
}

function check() {
	if ($_POST['GAME_MODE_NAME']) {
		echo "GameMode is OK.\n";
	} else {
		echo "[ERROR]Game Mode Name is not setted.\n";
		return False;
	}

	if ($_POST['NUMBER_OF_CARDS_PER_PLAYER']) {
		echo "Number of Cards per Player is OK.\n";
	} else {
		echo "[ERROR]Number of Cards per Player is not setted.\n";
		return False;
	}

	if ($_POST['MAX_NUMBER_OF_PLAYERS']) {
		echo "Maximum Number of Players is OK.\n";
	} else {
		echo "[ERROR]Maximum Number of Players is not setted.\n";
		return False;
	}

	if ($_POST['MIN_NUMBER_OF_PLAYERS']) {
		echo "Minimum Number of Players is OK.\n";
	} else {
		echo "[ERROR]Minimum Number of Players is not setted.\n";
		return False;
	}

	if ($_POST['MAX_NUMBER_OF_CARDS_IN_ONE_TURN']) {
		echo "Maximum Number of Cards in One Turn is OK.\n";
	} else {
		echo "[ERROR]Maximum Number of Cards in One Turn is not setted.\n";
		return False;
	}

	if ($_POST['PLAYERS_ORDER_RANDOM']) {
		echo "Players Order Random is OK.\n";
	} else {
		echo "[ERROR]Players Order Random is not setted.\n";
		return False;
	}

	return True;

}



?>