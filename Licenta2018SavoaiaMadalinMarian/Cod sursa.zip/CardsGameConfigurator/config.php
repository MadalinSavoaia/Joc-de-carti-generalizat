<?php

// Header
echo '
	<link rel="stylesheet" href="header.css">

	<div>
		<h3>Cards Game Configurator</h3>
		<p>Configure your own type of game.</p>
	</div>
';


$properties = array(array("id" => "GAME_MODE_NAME",
					"name" => "Game Mode Name",
					"type" => "text",
					"min" => "1"),
array("id" => "NUMBER_OF_CARDS_PER_PLAYER",
					"name" => "Number of Cards per Player",
					"type" => "number",
					"min" => "1"),
array("id" => "MAX_NUMBER_OF_PLAYERS",
					"name" => "Maximum Number Players",
					"type" => "number",
					"min" => "2"),
array("id" => "MIN_NUMBER_OF_PLAYERS",
					"name" => "Minimum Number Players",
					"type" => "number",
					"min" => "2"),
array("id" => "NUMBER_OF_CARDS_FOR_WIN",
					"name" => "Number of Cards for Win",
					"type" => "number",
					"min" => "0"),
array("id" => "MAX_NUMBER_OF_CARDS_IN_ONE_TURN",
					"name" => "Maximum Number of Cards in One Turn",
					"type" => "number",
					"min" => "0"),
array("id" => "PLAYERS_ORDER_RANDOM",
					"name" => "Players Order Random",
					"type" => "radio",
					"values" => array("True", "False")));

$cards = array("1","2", "3", "4",
				"5", "6", "7", "8",
				"9", "10", "11", "12", "13", "14");

// Configurator
echo '
<form action="form.php" method="post">
	<div id="gameConfig">
';

for($index = 0; $index < sizeof($properties); $index++) {
	$property = $properties[$index];
	if ($property["type"] == "text") {
		echo "<div>";
		echo $property["name"] . ' <input type="text" name="' . $property["id"] . '" />';
		echo "</div>";
	} else if ($property["type"] == "number") {
		echo "<div>";
		echo $property["name"] . ' <input type="number" name="' . $property["id"] . '"  min="'. $property["min"] .'"/>';
		echo "</div>";
	} else if ($property["type"] == "radio") {
		echo "<div>";
		echo $property["name"];
		$values = $property["values"];
		for($index2 = 0; $index2 < sizeof($values); $index2++) {
			echo '<input type="radio" name="' . $property["id"] . '" value="' . $values[$index2] . '">' . $values[$index2] . ' ';
		}
		echo "</div>";
	}
}


// Select not initial cards

echo '<div class="gameConfigProperty">';
echo 'Select not initial cards <select name="NOT_INITIAL_CARDS[]" multiple>';

for($index = 0; $index < sizeof($cards); $index++) {

	$card = $cards[$index];
		echo '<option value="' . $card . '1">' . $card . ' &#9824</option>';
		echo '<option value="' . $card . '2">' . $card . ' &#9827</option>';
		echo '<option value="' . $card . '3">' . $card . ' &#9829</option>';
		echo '<option value="' . $card . '4">' . $card . ' &#9830</option>';
}


echo '</select>';
echo '</div>';

// Accepted Cards in one Turn

echo '<div>';
echo '<label>Accepted Cards Groups</label> </br>';
for($index = 1; $index <= 14; $index++) {
	echo '<input type="text" name="accepted_group_' . $index . '" placeholder="Group ' . $index . '"> </br>';
}
echo '</div>';


// Card Actions

echo '<div>
		<h4>Cards Actions</h4>
		<ul>';


	for($index = 1; $index <= sizeof($cards); $index++) {
		echo '<li>' . $index . ' &#9824 &#9827 &#9829 &#9830</li>';
		echo '	<div class="gameConfigProperty">
					Next Cards Accepted 
					<input type="text" name="' . $index . '_NEXT_CARDS_ACCEPTED">	
				</div>

				<div class="gameConfigProperty">
					Accept just same Symbol
					<input type="radio" name="' . $index . '_ACCEPT_JUST_SAME_SYMBOL" value="TRUE"> YES
					<input type="radio" name="' . $index . '_ACCEPT_JUST_SAME_SYMBOL" value="FALSE" checked> NO
				</div>

				<div class="gameConfigProperty">
					Add Next Player Cards
					<input type="number" name="' . $index . '_ADD_NEXT_PLAYER_CARDS" min=0>
				</div>

				<div class="gameConfigProperty">
					Remove Next Player Turns
					<input type="number" name="' . $index . '_REMOVE_NEXT_PLAYER_TURNS" min=0>
				</div>

				<div class="gameConfigProperty">
					Remove Add Next Player Cards
					<input type="radio" name="' . $index . '_REMOVE_ADD_NEXT_PLAYER_CARDS" value="TRUE"> YES
					<input type="radio" name="' . $index . '_REMOVE_ADD_NEXT_PLAYER_CARDS" value="FALSE" checked> NO
				</div>
		';
	}


echo '</ul>

	</div>';

echo ' </div>
<input type="Submit">
</form>
';
?>